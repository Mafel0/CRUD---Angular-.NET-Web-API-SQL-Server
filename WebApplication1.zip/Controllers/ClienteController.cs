﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data.SqlClient;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class ClienteController : ApiController
    {
        public HttpResponseMessage Get()
        {
            string query = @"
                    select ID_CLI, NOME_CLI, EMAIL_CLI, TELEFONE_CLI, CPF_CLI, RG_CLI,
                        CONVERT(VARCHAR(10), NASCI_CLI, 120) AS NASCI_CLI, ENDERECO_CLI, NMRCASA_CLI, CIDADE_CLI, ESTADO_CLI, 
                        DIVIDA_CLI 
                        FROM dbo.dbo_CLIENT";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["ClienteAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        public string Post(Cliente cli)
        {
            try
            {
                string query = @"
                    insert into dbo.dbo_CLIENT values           
                    (
                    '" + cli.nome_cli + @"',
                    '" + cli.email_cli + @"',
                    '" + cli.telefone_cli + @"',
                    '" + cli.cpf_cli + @"',
                    '" + cli.rg_cli + @"',
                    '" + cli.nasci_cli + @"',
                    '" + cli.endereco_cli + @"',
                    '" + cli.nmrcasa_cli + @"',
                    '" + cli.cidade_cli + @"',
                    '" + cli.estado_cli + @"',
                    '" + cli.divida_cli + @"'            
                    )";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ClienteAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "adicionado!";

            }
            catch (Exception)
            {

                return "falha ao adicionar!";
            }

        }

        public string Put(Cliente cli)
        {
            try
            {
                string query = @"
                    update dbo.dbo_CLIENT set 
                    NOME_CLI='" + cli.nome_cli + @"',
                    EMAIL_CLI='" + cli.email_cli + @"',
                    TELEFONE_CLI='" + cli.telefone_cli + @"',
                    CPF_CLI='" + cli.cpf_cli + @"',
                    RG_CLI='" + cli.rg_cli + @"',
                    NASCI_CLI='" + cli.nasci_cli + @"',
                    ENDERECO_CLI='" + cli.endereco_cli + @"',
                    NMRCASA_CLI='" + cli.nmrcasa_cli + @"',
                    CIDADE_CLI='" + cli.cidade_cli + @"',
                    ESTADO_CLI='" + cli.estado_cli + @"',
                    DIVIDA_CLI='" + cli.divida_cli + @"'
                    WHERE ID_CLI=" + cli.id_cli + @"
                    ";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ClienteAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "alterado!";

            }
            catch (Exception)
            {

                return "falha ao alterar!";
            }

        }

        public string Delete(int id)
        {
            try
            {
                string query = @"
                    delete from dbo.dbo_CLIENT
                    WHERE ID_CLI=" + id + @"
                    ";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["ClienteAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Deletado!";

            }
            catch (Exception)
            {

                return "Falha ao deletar!";
            }

        }

        /*
        [Route("api/Cliente/GetAllNomes")]
        [HttpGet]
        public HttpResponseMessage GetAllNomes()
        {

            string query = @"
                    select NOME_CLI from dbo.dbo_CLIENT";

            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["ClienteAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
        */

        //retornar o Cli somente pelo ID

        [HttpGet]
        [Route("api/Cliente/GetCliId/{id}")]
        public HttpResponseMessage GetCliId(int id)
        {

            string query = @"
                    select ID_CLI, NOME_CLI, EMAIL_CLI, TELEFONE_CLI, CPF_CLI, RG_CLI,
                        CONVERT(VARCHAR(10), NASCI_CLI, 120) AS NASCI_CLI, ENDERECO_CLI, NMRCASA_CLI, CIDADE_CLI, ESTADO_CLI, 
                        DIVIDA_CLI 
                        from dbo.dbo_CLIENT
                        WHERE ID_CLI=" + id + @"
                        ";

            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["ClienteAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }


        [Route("api/Cliente/GetDividendos")]
        [HttpGet]
        public HttpResponseMessage FiltroDivida()
        {
            string query = @"
                    select ID_CLI, NOME_CLI, EMAIL_CLI, TELEFONE_CLI, CPF_CLI, RG_CLI,
                        CONVERT(VARCHAR(10), NASCI_CLI, 120) AS NASCI_CLI, ENDERECO_CLI, NMRCASA_CLI, CIDADE_CLI, ESTADO_CLI, 
                        DIVIDA_CLI 
                        FROM dbo.dbo_CLIENT
                        WHERE DIVIDA_CLI > 0.0";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["ClienteAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [Route("api/Cliente/GetDividaTotal")]
        [HttpGet]
        public HttpResponseMessage GetDividaTotal()
        {

            string query = @"select DIVIDA_CLI FROM dbo_CLIENT where DIVIDA_CLI > 0;";

            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["ClienteAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

    }
}
