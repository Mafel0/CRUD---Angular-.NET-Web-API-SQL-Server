﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Cliente
    {
        public int id_cli { get; set; }
        public string nome_cli { get; set; }
        public string email_cli { get; set; }
        public string telefone_cli { get; set; }
        public string cpf_cli { get; set; }
        public string rg_cli { get; set; }
        public string nasci_cli { get; set; }
        public string endereco_cli { get; set; }
        public string nmrcasa_cli { get; set; }
        public string cidade_cli { get; set; }
        public string estado_cli { get; set; }
        public string divida_cli { get; set; }
    }
}